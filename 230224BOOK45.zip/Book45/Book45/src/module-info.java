/**
 * 
 */
/**
 * @author oum03
 *
 */
module Exam_221111 {
	requires java.sql;
	requires org.jsoup;
}