package com.book45.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book45.domain.BookReviewPageDTO;
import com.book45.domain.BookReviewVO;
import com.book45.domain.Criteria;
import com.book45.mapper.BookReviewMapper;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class BookReviewServiceImpl implements BookReviewService {

	@Autowired
	private BookReviewMapper mapper;

	@Override
	public int register(BookReviewVO vo) {
		
		log.info("register......" +vo);

		return mapper.insert(vo);
	}

	@Override
	public BookReviewVO get(Long num) {
		
		log.info("get......" +num);

		return mapper.read(num);
	}

	@Override
	public int modify(BookReviewVO vo) {
		
		log.info("modify......" +vo);
		
		return mapper.update(vo);
	}

	@Override
	public int remove(Long num) {
		
		log.info("remove......" +num);

		return mapper.delete(num);
	}

	@Override
	public List<BookReviewVO> getList(Criteria cri, Long isbn) {
		
		log.info("도서 리뷰 리스트 : " +isbn);
		
		return mapper.getListWithPaging(cri, isbn);
	}

	@Override
	public BookReviewPageDTO getListPage(Criteria cri, Long isbn) {

		return new BookReviewPageDTO(
				mapper.getCountByIsbn(isbn),
				mapper.getListWithPaging(cri, isbn));
	}
	
	
	
	
}
