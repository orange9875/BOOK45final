package com.book45.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BookReviewPageDTO {

	private int bookReviewCnt;
	private List<BookReviewVO> list;
}
