package com.book45.domain;

import lombok.Data;
/*OrderItemDTO은 하나의 주문 상품 정보를 담는다.
 * OrderDTO는 배송지 정보, 사용 포인트 정보, 여러 개의 주문 상품 정보를 담는다.
 * (OrderItemDTO를 요소로 가지는 List객체를 통해 여러 주문 상품 정보를 가지게 된다.)
 * */
@Data
public class OrderItemDTO {
	
	//orderItem테이블의 기본키
	private int orderItemNum;
	//orders테이블의 기본키. 주문번호
	private String orderNum;  
	
	private String id;
	private Long isbn;
	private Long productNum;
	private int price;
	private int albumPrice;
	private int amount;
	//DB테이블 존재하지 않는 데이터
	private int totalPrice; //나중에 빠질 수도 있음
	
	public void initTotal() {
		this.totalPrice = this.price * this.amount + this.albumPrice * this.amount;
	}
}
