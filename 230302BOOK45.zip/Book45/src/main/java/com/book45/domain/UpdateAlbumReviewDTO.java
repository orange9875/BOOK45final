package com.book45.domain;

import lombok.Data;

@Data
public class UpdateAlbumReviewDTO {

	private Long productNum;
	private double ratingAvg;
}
