package com.book45.domain;

import java.util.Date;

import lombok.Data;

/*select o.id, o.name, o.phone, o.orderDate, o.zipCode, o.addressRoad, o.orderState, o.deliverCost, o.usePoint, 
			oi.price, oi.albumPrice, oi.amount,
			b.title, b.price, b.pictureurl,
			a.albumTitle, a.albumPrice, a.albumPictureUrl
 * */
@Data
public class OrderListDTO {

	private String orderNum;
	private String id;
	private String name;
	private String phone;
	private Date orderDate;
	private String zipCode;
	private String addressRoad;
	private String orderState;
	private int deliverCost;
	private int usePoint;
	
	private int price;
	private String title;
	private String pictureUrl;
	
	private int albumPrice;
	private String albumTitle;
	private String albumPictureUrl;
	
}
