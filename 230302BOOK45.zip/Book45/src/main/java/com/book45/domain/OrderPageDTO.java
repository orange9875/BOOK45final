package com.book45.domain;

import java.util.List;

import lombok.Data;
//OrderPageItemDTO클래스의 객체를 요소로 가지는 List타입의 변수를 가지는 클래스

@Data
public class OrderPageDTO {
	
	private List<OrderPageItemDTO> orders;
}
