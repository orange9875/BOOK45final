package com.book45.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.book45.domain.OrderCancelDTO;
import com.book45.domain.OrderDTO;
import com.book45.domain.OrderItemDTO;
import com.book45.domain.OrderPageDTO;
import com.book45.domain.OrderPageItemDTO;
import com.book45.service.MemberService;
import com.book45.service.OrderService;

import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/order/*")
public class OrderController {
   @Autowired
   private OrderService orderService;
   
   @Autowired
   private MemberService memberService;
   
   @RequestMapping(value="/orderPage/{id}", method = RequestMethod.GET)
      public String orderPage(@PathVariable("id") String id, @RequestParam(required=false, value="isbn") Long isbn , @RequestParam(required=false, value="productNum") Long productNum, OrderPageDTO orderPage, Model model) {
         log.info("주문 페이지"); 
         log.info("id: " + id);
         log.info("orders: " + orderPage.getOrders());
         
         Long inputIsbn = null;
         Long inputProductNum = null;
         
         
         for(OrderPageItemDTO or:orderPage.getOrders()) {
            
            if(inputIsbn==null)
               inputIsbn = or.getIsbn();
            if(inputProductNum==null)
               inputProductNum = or.getProductNum();
         }
         log.info(inputIsbn);
         log.info(inputProductNum);

         
         if (inputProductNum == null) {
            if(inputIsbn != null) {
               model.addAttribute("orderBookList", orderService.getBooksInfo(orderPage.getOrders()));
               model.addAttribute("member", memberService.getMember(id));
            
               log.info("getBooksInfo: "+ orderService.getBooksInfo(orderPage.getOrders()));
            }
         } else if (inputIsbn == null) {
            if(inputProductNum != null) {
               model.addAttribute("orderAlbumList", orderService.getAlbumsInfo(orderPage.getOrders()));
               model.addAttribute("member", memberService.getMember(id));
            
               log.info("getAlbumsInfo: "+ orderService.getAlbumsInfo(orderPage.getOrders()));
            }
         } else if (inputIsbn != null && inputProductNum != null){
            
            List<OrderPageItemDTO> IsbnDTOList = new ArrayList<>();
            List<OrderPageItemDTO> ProductDTOList = new ArrayList<>();
            
            for(OrderPageItemDTO or:orderPage.getOrders()){
               if(or.getIsbn()!=null) IsbnDTOList.add(or);
               else ProductDTOList.add(or);
               }
            
              model.addAttribute("orderBookList", orderService.getBooksInfo(IsbnDTOList)); 
               model.addAttribute("orderAlbumList", orderService.getAlbumsInfo(ProductDTOList));
               model.addAttribute("member", memberService.getMember(id));      
               
               log.info("getBooksInfo: "+ orderService.getBooksInfo(IsbnDTOList));
               log.info("getAlbumsInfo: "+ orderService.getAlbumsInfo(ProductDTOList));
         }
         
         return "/order/orderPage";
      }
//   @RequestMapping(value="/order", method = RequestMethod.POST)
//   public String orderPagePost(OrderDTO ord, Model model) {
//      
//	   
//	   
//	   
////	   model.addAttribute("orderBook",orderService.orderBook(ord));
//      //orderService.orderBook(ord);
//	  orderService.orderAlbum(ord);
//      log.info("od: " + ord);
//      
//      return "redirect:/main";
//   }
   
   @RequestMapping(value="/order", method = {RequestMethod.POST, RequestMethod.GET})
   public String orderPagePost(OrderDTO ord, Long isbn, Long productNum, HttpServletRequest request) {
      
      Long inputIsbn = null; 
       Long inputProductNum = null;
      
       for(OrderItemDTO oid:ord.getOrders()) {
            
            if(inputIsbn==null)
               inputIsbn = oid.getIsbn();
            if(inputProductNum==null)
               inputProductNum = oid.getProductNum();
         }
         
         if (inputProductNum == null) {
            if(inputIsbn != null) {
               orderService.orderBook(ord);
               log.info("=====book======");
            }
         } else if (inputIsbn == null) {
            if(inputProductNum != null) {
               orderService.orderAlbum(ord);
               log.info("======album=====");
            }
         } else if (inputIsbn != null && inputProductNum != null){
            
            List<OrderItemDTO> IsbnDTOList = new ArrayList<>();
            List<OrderItemDTO> ProductDTOList = new ArrayList<>();
            
            for(OrderItemDTO oid:ord.getOrders()){
               if(oid.getIsbn()!=null) IsbnDTOList.add(oid);
               else ProductDTOList.add(oid);
               }
            orderService.orderBook(ord);
            orderService.orderAlbum(ord);
         }
         
      return "redirect:/main";
   }
   
   /* 회원 주문 삭제 */
   @RequestMapping(value="/memberOrderCancel")
   public String membeOrderCancelPOST(OrderCancelDTO orderCancel) {
      
      orderService.orderCancel(orderCancel);
      return "redirect:/member/orderList?keyword=" + orderCancel.getKeyword() + "&amount="+orderCancel.getAmount() + "&pageNum="+orderCancel.getPageNum();
   }
   
   /* 관리자 주문 삭제 */
   @RequestMapping(value="/adminOrderCancel")
   public String adminOrderCancelPOST(OrderCancelDTO orderCancel) {
      
      orderService.orderCancel(orderCancel);
      return "redirect:/admin/orderList?keyword=" + orderCancel.getKeyword() + "&amount="+orderCancel.getAmount() + "&pageNum="+orderCancel.getPageNum();
   }

}