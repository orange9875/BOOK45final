package com.book45.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book45.domain.AlbumReviewPageDTO;
import com.book45.domain.AlbumReviewVO;
import com.book45.domain.Criteria;
import com.book45.mapper.AlbumReviewMapper;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class AlbumReviewServiceImpl implements AlbumReviewService {
	
	@Autowired
	private AlbumReviewMapper mapper;
	
	@Override
	public int register(AlbumReviewVO vo) {
		
		log.info("register......" +vo);
		
		return mapper.insert(vo);
	}

	@Override
	public AlbumReviewVO get(Long num) {
	
		log.info("get......" +num);

		return mapper.read(num);
	}

	@Override
	public int modify(AlbumReviewVO vo) {
		
		log.info("modify......" +vo);
		
		return mapper.update(vo);
	}

	@Override
	public int remove(Long num) {

		log.info("remove......" +num);

		return mapper.delete(num);
	}

	@Override
	public List<AlbumReviewVO> getList(Criteria cri, Long productNum) {

		log.info("get albumReview List of a Album......" +productNum);
		
		return mapper.getListWithPaging(cri, productNum);
	}

	@Override
	public AlbumReviewPageDTO getListPage(Criteria cri, Long productNum) {

		return new AlbumReviewPageDTO(
				mapper.getCountByProductNum(productNum),
				mapper.getListWithPaging(cri, productNum));
	}

//	@Override
//	public int checkAlbumReview(AlbumReviewVO vo) {
//
//		return mapper.checkAlbumReview(vo);
//		
////		int result = mapper.checkAlbumReview(vo);
////		
////		if(result == null) {
////			
////			return "0";
////			
////		}else {
////			
////			return "1";
////		}
//		
//	}
	
	
	

	
}
