package com.book45.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.book45.domain.BookVO;
import com.book45.domain.CartDTO;
import com.book45.domain.MemberVO;
import com.book45.domain.OrderCancelDTO;
import com.book45.domain.OrderDTO;
import com.book45.domain.OrderItemDTO;
import com.book45.domain.OrderPageItemDTO;
import com.book45.mapper.BookMapper;
import com.book45.mapper.CartMapper;
import com.book45.mapper.MemberMapper;
import com.book45.mapper.OrderMapper;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderMapper ordersMapper;

	@Autowired
	private MemberMapper memberMapper;

	@Autowired
	private CartMapper cartMapper;

	@Autowired
	private BookMapper bookMapper;

	@Override
	public List<OrderPageItemDTO> getBooksInfo(List<OrderPageItemDTO> orders) {
		List<OrderPageItemDTO> result = new ArrayList<>();

		for (OrderPageItemDTO opi : orders) {
			OrderPageItemDTO booksInfo = ordersMapper.getBooksInfo(opi.getIsbn());
			booksInfo.setAmount(opi.getAmount());
			booksInfo.initTotal();
			result.add(booksInfo);
		}

		return result;
	}

	@Override
	public List<OrderPageItemDTO> getAlbumsInfo(List<OrderPageItemDTO> orderPageItem) {
		List<OrderPageItemDTO> result = new ArrayList<>();

		for (OrderPageItemDTO opi : orderPageItem) {
			OrderPageItemDTO albumsInfo = ordersMapper.getAlbumsInfo(opi.getProductNum());
			albumsInfo.setAmount(opi.getAmount());
			albumsInfo.initTotal();
			result.add(albumsInfo);
		}

		return result;
	}

	/* 도서 주문 */
	@Override
	@Transactional
	public void orderBook(OrderDTO ord) {

	/* 사용할 데이터 가져오기 */
		/* 회원 정보 */
		MemberVO member = memberMapper.getMember(ord.getId());
		/* 주문 정보 */
		List<OrderItemDTO> ords = new ArrayList<>();
		for(OrderItemDTO oit : ord.getOrderItem()) {

			OrderItemDTO orderItem = ordersMapper.getOrderBooksInfo(oit.getIsbn());

			// 수량 셋팅
			orderItem.setAmount(oit.getAmount());
			// 기본 정보 셋팅
			orderItem.initTotal();
			// List객체 추가
			ords.add(orderItem);

		}
		// OrderDTO 셋팅
		ord.setOrderItem(ords);
		ord.getOrderPriceInfo();

	/* DB 주문, 주문상품(,배송정보) 넣기 */
		/* orderNum만들기 및 OrderDTO객체 orderNum에 저장 */
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("_yyyyMMddmm");
		String orderNum = member.getId() + format.format(date);
		ord.setOrderNum(orderNum);

		/* DB넣기 */
		ordersMapper.enrollOrder(ord);
		for (OrderItemDTO oit : ord.getOrderItem()) { // orderItem 등록

			oit.setOrderNum(orderNum);
			ordersMapper.enrollOrderBookItem(oit);
		}

	/* 비용 포인트 변동 적용 */

		/* 포인트 차감, 포인트 증가 & 변동 포인트(point) Member객체 적용 */
		int calPoint = member.getPoint();
		calPoint = calPoint - ord.getUsePoint(); // 기존 포인트 - 사용 포인트
		member.setPoint(calPoint);

		/* 변동 포인트 DB적용 */
		ordersMapper.deductPoint(member);

	/* 재고 변동 적용 */
		for (OrderItemDTO oit : ord.getOrderItem()) {

			/* 변동 재고 값 구하기 */
			BookVO book = bookMapper.read(oit.getIsbn());
			book.setStock(book.getStock() - oit.getAmount());
			/* 변동 값 DB 적용 */
			ordersMapper.deductBookStock(book);
		}

	/* 장바구니 제거 */
		for (OrderItemDTO oit : ord.getOrderItem()) {
			CartDTO cart = new CartDTO();
			cart.setId(ord.getId());
			cart.setIsbn(oit.getIsbn());

			cartMapper.deleteBookOrderCart(cart);
		}
	}

	/*
	 * @Override
	 * 
	 * @Transactional public void orderAlbum(OrderDTO ord) {
	 * 
	 * 사용할 데이터 가져오기 회원 정보 MemberVO member = memberMapper.getMember(ord.getId()); 주문
	 * 정보 List<OrderItemDTO> ords = new ArrayList<>(); for(OrderItemDTO oit :
	 * ord.getOrderItem()) {
	 * 
	 * OrderItemDTO orderItem =
	 * ordersMapper.getOrderAlbumsInfo(oit.getProductNum());
	 * 
	 * //수량 셋팅 orderItem.setAmount(oit.getAmount()); //기본 정보 셋팅
	 * orderItem.initTotal(); //List객체 추가 ords.add(orderItem);
	 * 
	 * } //OrderDTO 셋팅 ord.setOrderItem(ords); ord.getOrderPriceInfo();
	 * 
	 * DB 주문, 주문상품(,배송정보) 넣기 orderNum만들기 및 OrderDTO객체 orderId에 저장 Date date = new
	 * Date(); SimpleDateFormat format = new SimpleDateFormat("_yyyyMMddmm"); String
	 * orderNum = member.getId() + format.format(date); ord.setOrderNum(orderNum);
	 * 
	 * DB넣기 ordersMapper.enrollOrder(ord); for(OrderItemDTO oit :
	 * ord.getOrderItem()) { //orderItem 등록
	 * 
	 * oit.setOrderNum(orderNum); ordersMapper.enrollOrderAlbumItem(oit); }
	 * 
	 * 비용 포인트 변동 적용
	 * 
	 * 포인트 차감, 포인트 증가 & 변동 포인트(point) Member객체 적용 int calPoint = member.getPoint();
	 * calPoint = calPoint - ord.getUsePoint(); //기존 포인트 - 사용 포인트
	 * member.setPoint(calPoint);
	 * 
	 * 변동 포인트 DB적용 ordersMapper.deductPoint(member);
	 * 
	 * 재고 변동 적용 for(OrderItemDTO oit : ord.getOrderItem()) {
	 * 
	 * 변동 재고 값 구하기 AlbumVO album = bookMapper.read(oit.getProductNum());
	 * album.setStock(album.getStock() - oit.getAmount()); 변동 값 DB 적용
	 * ordersMapper.deductBookStock(album); }
	 * 
	 * 장바구니 제거 for(OrderItemDTO oit : ord.getOrderItem()) { CartDTO cart = new
	 * CartDTO(); cart.setId(ord.getId()); cart.setProductNum(ord.getProductNum());
	 * 
	 * cartMapper.deleteBookOrderCart(cart); } }
	 */
	
	@Override
	public void orderCancel(OrderCancelDTO orderCancel) {

/* 주문, 주문상품 객체 */
	/* 회원 */
		MemberVO member = memberMapper.getMember(orderCancel.getId());
	/* 주문 상품 */
		List<OrderItemDTO> ords = ordersMapper.getOrderItemInfo(orderCancel.getId());
		for(OrderItemDTO ord : ords) {
			ord.initTotal();
		}
	/* 주문 */
		OrderDTO orders = ordersMapper.getOrder(orderCancel.getId());
		orders.setOrderItem(ords);
		
		orders.getOrderPriceInfo();

/* 주문상품 취소 DB */
		ordersMapper.orderCancel(orderCancel.getId());
		
/* 포인트, 재고 변환 */
	/* 포인트 */
		int calPoint = member.getPoint();
		calPoint = calPoint + orders.getUsePoint();
		member.setPoint(calPoint);
		
			/* DB적용 */
			ordersMapper.deductPoint(member);
		/* 재고 */
			for(OrderItemDTO ord : orders.getOrderItem()) {
				
				BookVO book = bookMapper.read(ord.getIsbn());
				book.setStock(book.getStock() + ord.getAmount());
				ordersMapper.deductBookStock(book);
			}
	}
	
	

}
