package com.book45.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.book45.domain.Criteria;
import com.book45.domain.MemberVO;
import com.book45.domain.OrderCancelDTO;
import com.book45.domain.OrderDTO;
import com.book45.domain.PageDTO;
import com.book45.service.MemberService;
import com.book45.service.OrderService;

import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/member/*")
public class MemberController {
   @Autowired
   private MemberService memberService;
   
   @Autowired
   private OrderService orderService;
   
   /* 회원가입 페이지 이동 */
   @RequestMapping(value = "/join", method = RequestMethod.GET)
   public void joinGet() {
      log.info("회원가입 페이지");
   }
   
   /* 회원 약관 페이지 이동 */
   @RequestMapping(value="/terms", method = RequestMethod.GET)
   public void termsGet() {
	   log.info("회원가입 약관 페이지");
   }
   
   /* 회원가입 */
   @RequestMapping(value = "/join", method = RequestMethod.POST)
   public String joinPost(MemberVO member) throws Exception {
      log.info("회원가입 진행 중");
      memberService.memberJoin(member);
      log.info("회원가입 성공");
      
      return "redirect:/main";
   }
   
   /* 아이디 중복체크 */
   @RequestMapping(value = "/idCheck", method = RequestMethod.GET)
   public void idCheckGet() {
      log.info("아이디 중복체크 페이지");
   }
   
   
   /* 아이디 중복체크*/
   @RequestMapping(value = "/idCheck", method = RequestMethod.POST)
   @ResponseBody
   public String idCheckPost(String id) throws Exception {
      log.info("아이디 중복체크");
      int result = memberService.idCheck(id);
      
      if (result != 0) {
         return "fail";
      } else {
         return "success";
      }
   }
   
   /* 닉네임 중복체크 */
   @RequestMapping(value = "/nicknameCheck", method = RequestMethod.POST)
   @ResponseBody
   public String nicknameCheckPost(String nickname) throws Exception {
      log.info("닉네임 중복체크");
      int result = memberService.nickNameCheck(nickname);
      
      if (result != 0) {
         return "fail";
      } else {
         return "success";
      }
   }
   
   /* 로그인 페이지 이동 */
   @RequestMapping(value = "/login", method = RequestMethod.GET)
   public void loginGet() {
      log.info("로그인 페이지");
   }
   
   /* 로그인 */
   @RequestMapping(value = "/login.do", method = RequestMethod.POST)
   public String loginPost(HttpServletRequest request, MemberVO member, RedirectAttributes rttr) throws Exception {
      HttpSession session = request.getSession();
      MemberVO member2 = memberService.memberLogin(member);
      
      if (member2 == null) {
         int result = 0;
         rttr.addFlashAttribute("result", result);
         return "redirect:/member/login";
      } 
      
      session.setAttribute("id", member2.getId());
      session.setAttribute("member", member2);
      
      return "redirect:/main";
      
   }
   
//   @RequestMapping(value = "/login", method = RequestMethod.POST)
//   public String loginPost(HttpServletRequest request, MemberVO member, RedirectAttributes rttr) throws Exception {
//      log.info("로그인 시도 중");
//      HttpSession session = request.getSession();
//      // 아이디 비번 다 맞아야 정보 들어옴
//      MemberVO member2 = memberService.memberLogin(member);
//      
//      String id = member.getId();
//      String pass = member.getPass();
//      // 아이디만 맞아도 정보 들어옴
//      MemberVO member3 = memberService.getMember(id);
//      
//      // 일치하는 아이디 값이 없을 때
//      if (member2 == null) {
//         int result = 0;
//         rttr.addFlashAttribute("result", result);
//         return "redirect:/member/login";
//      }
//      
//      // 아이디는 일치 but 비밀번호 불일치
//      if (member3 != null) {
//         int result = -1;
//         rttr.addFlashAttribute("result", result);
//         return "redirect:/member/login";
//      }
//      
//      session.setAttribute("id", member2.getId());
//      session.setAttribute("member", member2);
//      
//      return "redirect:/main";
//      
//   }
   
//   @RequestMapping(value = "/login", method = RequestMethod.POST)
//   public String loginPost(HttpSession session, MemberVO member, RedirectAttributes rttr) throws Exception {
//      log.info("로그인 시도");
//      MemberVO member2 = memberService.memberLogin(member);
//      
//      if (member2 != null) {
//         session.setAttribute("id", member2.getId());
//         rttr.addFlashAttribute("member", member2);
//         return "redirect:/main";
//      } else {
//         return "redirect:/member/login";
//      }
//   }
   
   /* 메인 페이지 로그아웃 */
   @RequestMapping(value = "/logout", method = RequestMethod.GET)
   public String logoutGet(HttpServletRequest request) {
      log.info("메인 페이지에서 로그아웃 시도 중");
      HttpSession session = request.getSession();
      session.invalidate();
      
      return "redirect:/main";
   }
   
   /* 비동기 방식 로그아웃 */
   @RequestMapping(value = "/logout", method = RequestMethod.POST)
   @ResponseBody
   public void logoutPost(HttpServletRequest request) {
      log.info("비동기 방식 로그아웃 시도 중");
      HttpSession session = request.getSession();
      session.invalidate();
   }
   
   /* 마이페이지 */
   @RequestMapping(value = "/myPage", method = RequestMethod.GET)
   public void myPage(HttpServletRequest request, Model model) {
      log.info("마이페이지");
      HttpSession session = request.getSession();
      String id = (String)session.getAttribute("id");
      MemberVO member = memberService.getMember(id);
      log.info("member: " + member);
      log.info("id: " + id);
      model.addAttribute("member", member);
   }
   
   /* 회원 정보 수정 페이지 이동 */
   @GetMapping("/update")
   public void updateMyInfoGet(HttpServletRequest request, Model model) {
      log.info("회원 정보 수정");
      HttpSession session = request.getSession();
      String id = (String)session.getAttribute("id");
      MemberVO member = memberService.getMember(id);
      log.info("member: " + member);
      log.info("id: " + id);
      model.addAttribute("member", member);
   }
   
   /* 회원 정보 수정 */
   @RequestMapping(value = "/update", method = RequestMethod.POST)
   public String updateMyInfoPost(@ModelAttribute("member") MemberVO member, RedirectAttributes rttr) {
      log.info("회원 정보 수정 중");
      
      if (memberService.updateMypage(member) == 1) {
         rttr.addFlashAttribute("result", "update");
      }
      
      log.info("member: " + member);
      return "redirect:/member/myPage";
   }
   
   /* 회원 탈퇴 */
   @RequestMapping(value = "/delete", method = RequestMethod.POST)
   public String deleteMember(HttpServletRequest request, RedirectAttributes rttr) {
      log.info("회원 탈퇴");
      HttpSession session = request.getSession();
      String id = (String)session.getAttribute("id");
      if (memberService.deleteMember(id) == 1) {
         rttr.addFlashAttribute("result", "delete");
      }
      
      return "redirect:/member/logout";
   }
   
   /* 회원 주문 리스트 */
   @GetMapping("/orderList")
   public String orderListGet(Criteria cri, Model model) {
	   
	   List<OrderDTO> list = memberService.getOrderList(cri);
	   
	   if(!list.isEmpty()) {
		   model.addAttribute("list", list);
		   model.addAttribute("pageMaker", new PageDTO(cri, memberService.getOrderTotal(cri)));
	   }else {
		   model.addAttribute("listCheck", "empty");
	   }
	   return "/member/orderList";
   }
   
   /* 주문 삭제 */
   @RequestMapping(value="/orderCancel", method = RequestMethod.POST)
   public String orderCalcelPOST(OrderCancelDTO orderCancel) {
	   
	   orderService.orderCancel(orderCancel);
	   
	   return "redirect:/member/orderList?keyword=" + orderCancel.getKeyword() + "&amount=" 
			   +orderCancel.getAmount() + "&pageNum=" + orderCancel.getPageNum();
	   
   }
   
   
}