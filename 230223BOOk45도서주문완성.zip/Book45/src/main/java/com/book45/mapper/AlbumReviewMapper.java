package com.book45.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.book45.domain.AlbumReviewVO;
import com.book45.domain.Criteria;

public interface AlbumReviewMapper {

	public int insert(AlbumReviewVO vo);
	
	public AlbumReviewVO read(Long num);
	
	public int delete(Long num);
	
	public int update(AlbumReviewVO albumReview);
	
	public List<AlbumReviewVO> getListWithPaging(
			@Param("cri") Criteria cri,
			@Param("productNum") Long productNum);
	
	public int getCountByProductNum(Long productNum);
	
	//댓글 존재 체크
	//public int checkAlbumReview(AlbumReviewVO vo);

}
