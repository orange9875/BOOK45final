package com.book45.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.book45.domain.CartDTO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class CartMapperTest {
	@Autowired
	private CartMapper cartMapper;
	
	@Test
	public void testAddBookCart() throws Exception {
		CartDTO cart = new CartDTO();
		cart.setId("aaa");
		cart.setIsbn(9791140701490L);
		cart.setAmount(1);
		
		cartMapper.addBookCart(cart);
		log.info("장바구니 번호: " + cart.getCartNum());
	}
	
	@Test
	public void testAddAlbumCart() throws Exception {
		CartDTO cart = new CartDTO();
		cart.setId("admin2");
		cart.setProductNum(115399619L);
		cart.setAmount(2);
		
		cartMapper.addAlbumCart(cart);
		log.info(cart);
	}
	
	@Test
	public void testModifyCount() {
		CartDTO cart = new CartDTO();
		cart.setCartNum(10);
		cart.setAmount(2);
		
		cartMapper.modifyCount(cart);
		
		log.info(cart);
	}
	
	@Test
	public void testDeleteCart() {
		int result = cartMapper.deleteCart(8);
		
		log.info("result: " + result);
	}
	
	@Test
	public void testGetCartList() {
		List<CartDTO> list = cartMapper.getCartList("aaa");
		for (CartDTO cart : list) {
			log.info(cart);
			cart.initTotal();
			log.info("init cart: " + cart);
		}
	}
	
	@Test
	public void testCheckBookCart() {
		CartDTO cart = new CartDTO();
		cart.setId("abc123");
		cart.setIsbn(9788959897094L);
		
		CartDTO resultCart = cartMapper.checkBookCart(cart);
		log.info("result: " + resultCart);
	}
	
	@Test
	public void testCheckAlbumCart() {
		CartDTO cart = new CartDTO();
		cart.setId("abc123");
		cart.setProductNum(115399619L);
		
		CartDTO resultCart = cartMapper.checkAlbumCart(cart);
		log.info("result: " + resultCart);
	}
	
	@Test
	public void testDeleteAll() {
		int result = cartMapper.deleteAll("admin");
		log.info("result: "+result);
		
	}
	
	@Test
	public void testSelectDelete() {
		CartDTO cart = new CartDTO();
		cart.setId("admin");
		cart.setCartNum(21);
		int result = cartMapper.selectDelete(cart);
		log.info("resul: "+result);
	}
	
	/* 주문 후 장바구니에서 삭제*/
	@Test
	public void testDeleteBookOrderCart() {
		
		String id = "admin";
		Long isbn = 9788901260716L;
		
		CartDTO cart = new CartDTO();
		cart.setId(id);
		cart.setIsbn(isbn);
		
		cartMapper.deleteBookOrderCart(cart);
		
	}
}
