package com.book45.mapper;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.book45.domain.BookVO;
import com.book45.domain.MemberVO;
import com.book45.domain.OrderDTO;
import com.book45.domain.OrderItemDTO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class OrderMapperTest {
	
	@Autowired
	private OrderMapper orderMapper;
	
	@Test
	public void testGetOrderBooksTest() {
		
		OrderItemDTO orderInfo = orderMapper.getOrderBooksInfo(9788959897094L);
		log.info("result: " + orderInfo);
	}
	
	@Test
	public void testGetOrderAlbumsTest() {
		OrderItemDTO orderInfo = orderMapper.getOrderAlbumsInfo(48644799L);
		log.info("result: " + orderInfo);
	}
	
	@Test
	public void enrollOrderTest() {
		
		OrderDTO order = new OrderDTO();
		List<OrderItemDTO> list = new ArrayList();
		
		OrderItemDTO orderItem = new OrderItemDTO();
		
		orderItem.setIsbn(9788959897094L);
		orderItem.setAmount(1);
		orderItem.setPrice(12600);
		orderItem.initTotal();
		
		order.setOrderItem(list);
		//order.setOrderNum(20230218);
		order.setName("이은주");
		order.setId("admin");
		order.setPhone("010-4769-4788");
		order.setZipCode("12345");
		order.setAddressRoad("수원시 영통구 매탄동");
		order.setAddressDetail("501호");
		//order.setOrderState("배송 준비");
		order.setDeliverCost(3000);
		order.setUsePoint(100000);
		
		orderMapper.enrollOrder(order);
		
	}
	
	@Test
	public void enrollAlbumOrderTest() {
		
		OrderDTO order = new OrderDTO();
		List<OrderItemDTO> list = new ArrayList();
		
		OrderItemDTO orderItem = new OrderItemDTO();
		
		orderItem.setProductNum(79660302L);
		orderItem.setAmount(2);
		orderItem.setPrice(16300);
		orderItem.initTotal();
		
		order.setOrderItem(list);
		//order.setOrderNum(20230218);
		order.setName("이은주");
		order.setId("admin");
		order.setPhone("010-4769-4788");
		order.setZipCode("12345");
		order.setAddressRoad("수원시 영통구 매탄동");
		order.setAddressDetail("501호");
		//order.setOrderState("배송 준비");
		order.setDeliverCost(3000);
		order.setUsePoint(100000);
		
		orderMapper.enrollOrder(order);
		
	}
	
	/* 도서 orderItem테이블 등록 */
	@Test
	public void enrollOrderBookItemTest() {
		
		OrderItemDTO orderItem = new OrderItemDTO();
		
		orderItem.setOrderNum("1");
		orderItem.setIsbn(9791161571379L);
		orderItem.setAmount(3);
		orderItem.setPrice(12600);
		orderItem.initTotal();
		orderMapper.enrollOrderBookItem(orderItem);
		
	}
	
	@Test
	public void enrollOrderAlbumTest(){
		
		OrderItemDTO orderItem = new OrderItemDTO();
		
		orderItem.setOrderNum("22");
		orderItem.setProductNum(79660302L);
		orderItem.setAmount(2);
		orderItem.setAlbumPrice(16300);
		orderItem.initTotal();
		orderMapper.enrollOrderAlbumItem(orderItem);
	}
	
	@Test
	public void deductPointTest() {
		
		MemberVO member = new MemberVO();
		
		member.setId("admin");
		member.setPoint(50000);
		
		orderMapper.deductPoint(member);
	}
	
	/*상품 재고 변경*/
	@Test
	public void deductBookStockTest() {
		
		BookVO book = new BookVO();
		
		book.setIsbn(9791161571379L);
		book.setStock(9);
		
		orderMapper.deductBookStock(book);
	}
	
	/*
	 * @Test public void deductAlbumStockTest() {
	 * 
	 * 
	 * }
	 */
	
	
}
